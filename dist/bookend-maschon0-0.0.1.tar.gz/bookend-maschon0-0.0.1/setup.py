#cython: language_level=3
import setuptools
# from distutils.core import setup
# from Cython.Build import cythonize
# import numpy

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="bookend-maschon0", # Replace with your own username
    version="0.0.1",
    author="Michael A. Schon",
    author_email="michael.schon@gmi.oeaw.ac.at",
    description="End-guided transcript assembler for short and long RNA-seq reads.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Gregor-Mendel-Institute/bookend",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)

# setup(name="_fasta_utils", ext_modules=cythonize('_fasta_utils.pyx'),)
# setup(name="_rnaseq_utils", ext_modules=cythonize('_rnaseq_utils.pyx'), include_dirs=[numpy.get_include()])
# setup(name="_element_graph", ext_modules=cythonize('_element_graph.pyx', annotate=True), include_dirs=[numpy.get_include()])
# setup(name="_assembly_utils", ext_modules=cythonize('_assembly_utils.pyx', annotate=True), include_dirs=[numpy.get_include()])
# setup(name="_pq", ext_modules=cythonize('_pq.pyx'),)

